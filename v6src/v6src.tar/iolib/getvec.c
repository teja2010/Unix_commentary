getvec (n)
{
return (alloc(n));
}
